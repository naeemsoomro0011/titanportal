import { asyncHandler } from '../middleware/errorHandler.js'
<<<<<<< HEAD

export const uploadImage = asyncHandler(async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'No file uploaded.' })
  // Store a RELATIVE path (not an absolute http://host:port/... URL). If we
  // baked in the current BASE_URL/host/port here, any saved photo would
  // permanently break the moment the backend runs on a different port or
  // host (a very common local-dev situation) - the <img> would then fail to
  // load and the UI would silently fall back to the default initials
  // avatar, making it look like the user's chosen photo "disappeared" even
  // though it's sitting safely on disk and in the database. A relative path
  // is always resolved against whatever API origin the frontend is
  // currently talking to (see Avatar.jsx), so it keeps working no matter
  // what port/host the backend happens to be on.
  const url = `/uploads/${req.file.filename}`
  res.status(201).json({ url })
=======
import cloudinary from '../config/cloudinary.js'

function uploadBufferToCloudinary(buffer) {
  return new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(
      { folder: 'titan-portal', resource_type: 'image' },
      (err, result) => (err ? reject(err) : resolve(result))
    )
    stream.end(buffer)
  })
}

export const uploadImage = asyncHandler(async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'No file uploaded.' })

  // Uploaded straight to Cloudinary instead of local disk: Vercel's
  // filesystem is read-only/ephemeral for serverless functions, so a file
  // saved locally would not reliably survive between requests or
  // redeploys. Cloudinary gives back a permanent https:// URL, which the
  // frontend's resolvePhotoUrl() (Avatar.jsx) already passes through
  // untouched since it recognizes absolute URLs - no other change needed.
  const result = await uploadBufferToCloudinary(req.file.buffer)
  res.status(201).json({ url: result.secure_url })
>>>>>>> ab8999e3ce6fdf255870a670e710c3714f7634fa
})

import { useState } from 'react'
<<<<<<< HEAD
import { faIdCard, faRightToBracket } from '@fortawesome/free-solid-svg-icons'
import { Field, PasswordField, SubmitButton } from '../../../../Pages/login/Controls.jsx'
import { focusField } from '../../../../Pages/login/focusField.js'

function StudentLoginForm({ onSubmit }) {
  const [cnic, setCnic] = useState('')
  const [password, setPassword] = useState('')
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)

  const clearError = (key) => {
    if (errors[key]) setErrors((prev) => ({ ...prev, [key]: '' }))
  }

  const handleSubmit = async (e) => {
=======
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faIdCard, faLock, faEye, faEyeSlash, faRightToBracket, faChalkboardUser, faUserShield } from '@fortawesome/free-solid-svg-icons'

function StudentLoginForm({ onSubmit, onSwitchToTeacher, onSwitchToAdmin }) {
  const [cnic, setCnic] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [errors, setErrors] = useState({})

  const handleSubmit = (e) => {
>>>>>>> ab8999e3ce6fdf255870a670e710c3714f7634fa
    e.preventDefault()
    const newErrors = {}
    if (!cnic.trim()) newErrors.cnic = 'CNIC is required'
    if (!password.trim()) newErrors.password = 'Password is required'
    setErrors(newErrors)

<<<<<<< HEAD
    if (newErrors.cnic) return focusField('student-cnic')
    if (newErrors.password) return focusField('student-password')

    setLoading(true)
    try {
      await onSubmit({ cnic, password })
    } finally {
      setLoading(false)
=======
    if (Object.keys(newErrors).length === 0) {
      onSubmit({ cnic, password })
>>>>>>> ab8999e3ce6fdf255870a670e710c3714f7634fa
    }
  }

  return (
<<<<<<< HEAD
    <form className="tl-form" onSubmit={handleSubmit} noValidate>
      <h2 className="tl-form-title">Login</h2>
      <p className="tl-form-text">
        Kindly provide the CNIC number and password used during SMIT course registration.
      </p>

      <Field
        id="student-cnic"
        label="CNIC"
        icon={faIdCard}
        value={cnic}
        onChange={(e) => { setCnic(e.target.value); clearError('cnic') }}
        error={errors.cnic}
        placeholder="42101-1234567-1"
        autoComplete="username"
      />

      <PasswordField
        id="student-password"
        value={password}
        onChange={(e) => { setPassword(e.target.value); clearError('password') }}
        error={errors.password}
        placeholder="Enter your password"
      />

      <SubmitButton loading={loading} loadingText="Checking details…" icon={faRightToBracket}>
        Login
      </SubmitButton>
=======
    <form className="auth-form" onSubmit={handleSubmit} noValidate>
      <h3 className="auth-form-heading">Login</h3>
      <p className="auth-form-subtext">
        Kindly provide the CNIC number and password used during SMIT course registration.
      </p>

      <div className="auth-input-group">
        <label className="auth-input-label" htmlFor="student-cnic">
          CNIC <span className="auth-required-star">*</span>
        </label>
        <div className={`auth-input-wrap ${errors.cnic ? 'auth-input-wrap-error' : ''}`}>
          <FontAwesomeIcon icon={faIdCard} className="auth-input-icon" />
          <input
            id="student-cnic"
            type="text"
            className="auth-input"
            placeholder="42101-1234567-1"
            value={cnic}
            onChange={(e) => setCnic(e.target.value)}
          />
        </div>
        {errors.cnic && <span className="auth-error-text">{errors.cnic}</span>}
      </div>

      <div className="auth-input-group">
        <label className="auth-input-label" htmlFor="student-password">
          Password <span className="auth-required-star">*</span>
        </label>
        <div className={`auth-input-wrap ${errors.password ? 'auth-input-wrap-error' : ''}`}>
          <FontAwesomeIcon icon={faLock} className="auth-input-icon" />
          <input
            id="student-password"
            type={showPassword ? 'text' : 'password'}
            className="auth-input"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <FontAwesomeIcon
            icon={showPassword ? faEyeSlash : faEye}
            className="auth-eye-icon"
            onClick={() => setShowPassword(!showPassword)}
          />
        </div>
        {errors.password && <span className="auth-error-text">{errors.password}</span>}
      </div>

      <button type="submit" className="auth-btn-primary">
        <FontAwesomeIcon icon={faRightToBracket} /> Login
      </button>

      <button type="button" className="auth-btn-secondary" onClick={onSwitchToTeacher}>
        <FontAwesomeIcon icon={faChalkboardUser} /> Login as Teacher
      </button>

      <button type="button" className="auth-btn-secondary" onClick={onSwitchToAdmin}>
        <FontAwesomeIcon icon={faUserShield} /> Login as Admin
      </button>
>>>>>>> ab8999e3ce6fdf255870a670e710c3714f7634fa
    </form>
  )
}

export default StudentLoginForm

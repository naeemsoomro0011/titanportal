import { useState } from 'react'
<<<<<<< HEAD
import { faEnvelope, faRightToBracket } from '@fortawesome/free-solid-svg-icons'
import { Field, PasswordField, SubmitButton } from '../../../../Pages/login/Controls.jsx'
import { focusField } from '../../../../Pages/login/focusField.js'

function TeacherLoginForm({ onSubmit, onForgotPassword }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)

  const clearError = (key) => {
    if (errors[key]) setErrors((prev) => ({ ...prev, [key]: '' }))
  }

  const handleSubmit = async (e) => {
=======
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEnvelope, faLock, faEye, faEyeSlash, faRightToBracket, faGraduationCap } from '@fortawesome/free-solid-svg-icons'

function TeacherLoginForm({ onSubmit, onSwitchToStudent, onForgotPassword }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [errors, setErrors] = useState({})

  const handleSubmit = (e) => {
>>>>>>> ab8999e3ce6fdf255870a670e710c3714f7634fa
    e.preventDefault()
    const newErrors = {}
    if (!email.trim()) newErrors.email = 'Email is required'
    if (!password.trim()) newErrors.password = 'Password is required'
    setErrors(newErrors)

<<<<<<< HEAD
    if (newErrors.email) return focusField('teacher-email')
    if (newErrors.password) return focusField('teacher-password')

    setLoading(true)
    try {
      await onSubmit({ email, password })
    } finally {
      setLoading(false)
=======
    if (Object.keys(newErrors).length === 0) {
      onSubmit({ email, password })
>>>>>>> ab8999e3ce6fdf255870a670e710c3714f7634fa
    }
  }

  return (
<<<<<<< HEAD
    <form className="tl-form" onSubmit={handleSubmit} noValidate>
      <h2 className="tl-form-title">Login</h2>
      <p className="tl-form-text">
        Kindly provide the email and password used during SMIT course registration.
      </p>

      <Field
        id="teacher-email"
        label="Email"
        icon={faEnvelope}
        type="email"
        value={email}
        onChange={(e) => { setEmail(e.target.value); clearError('email') }}
        error={errors.email}
        placeholder="you@titan.edu.pk"
        autoComplete="email"
      />

      <PasswordField
        id="teacher-password"
        value={password}
        onChange={(e) => { setPassword(e.target.value); clearError('password') }}
        error={errors.password}
        placeholder="Enter your password"
      />

      <div className="tl-form-row">
        <button type="button" className="tl-link tl-link-gold" onClick={onForgotPassword}>
          Forgot Password?
        </button>
      </div>

      <SubmitButton loading={loading} loadingText="Checking details…" icon={faRightToBracket}>
        Login
      </SubmitButton>
=======
    <form className="auth-form" onSubmit={handleSubmit} noValidate>
      <h3 className="auth-form-heading">Login</h3>
      <p className="auth-form-subtext">
        Kindly provide the email and password used during SMIT course registration.
      </p>

      <div className="auth-input-group">
        <label className="auth-input-label" htmlFor="teacher-email">
          Email <span className="auth-required-star">*</span>
        </label>
        <div className={`auth-input-wrap ${errors.email ? 'auth-input-wrap-error' : ''}`}>
          <FontAwesomeIcon icon={faEnvelope} className="auth-input-icon" />
          <input
            id="teacher-email"
            type="email"
            className="auth-input"
            placeholder="you@titan.edu.pk"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        {errors.email && <span className="auth-error-text">{errors.email}</span>}
      </div>

      <div className="auth-input-group">
        <label className="auth-input-label" htmlFor="teacher-password">
          Password <span className="auth-required-star">*</span>
        </label>
        <div className={`auth-input-wrap ${errors.password ? 'auth-input-wrap-error' : ''}`}>
          <FontAwesomeIcon icon={faLock} className="auth-input-icon" />
          <input
            id="teacher-password"
            type={showPassword ? 'text' : 'password'}
            className="auth-input"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <FontAwesomeIcon
            icon={showPassword ? faEyeSlash : faEye}
            className="auth-eye-icon"
            onClick={() => setShowPassword(!showPassword)}
          />
        </div>
        {errors.password && <span className="auth-error-text">{errors.password}</span>}
      </div>

      <button type="submit" className="auth-btn-primary">
        <FontAwesomeIcon icon={faRightToBracket} /> Login
      </button>

      <button type="button" className="auth-link-btn" onClick={onForgotPassword}>
        Forgot Password?
      </button>

      <button type="button" className="auth-btn-secondary" onClick={onSwitchToStudent}>
        <FontAwesomeIcon icon={faGraduationCap} /> Login as Student
      </button>
>>>>>>> ab8999e3ce6fdf255870a670e710c3714f7634fa
    </form>
  )
}

export default TeacherLoginForm

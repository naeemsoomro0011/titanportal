<<<<<<< HEAD
import { useEffect, useRef, useState } from 'react'
import { Outlet, useNavigate } from 'react-router-dom'
import SubAdminSidebar from './SubAdminSidebar.jsx'
import SubAdminTooltips from './SubAdminTooltips.jsx'
import SubAdminRouteLoader from './SubAdminRouteLoader.jsx'
import LoginLoader from '../../../../../Pages/login/LoginLoader.jsx'
import { usePointerDepth } from '../../../../../Pages/login/usePointerDepth.js'
import { useAuth } from '../../../../../context/useAuth.js'
import '../SubAdmin.css'

// How long the "Logging out" loader shows before the session is cleared.
const LOGOUT_LOADER_MS = 1200
=======
import { useState } from 'react'
import { Outlet, useNavigate } from 'react-router-dom'
import SubAdminSidebar from './SubAdminSidebar.jsx'
import WaitingPopup from '../../../Media/WaitingPopup.jsx'
import { useAuth } from '../../../../../context/useAuth.js'
>>>>>>> ab8999e3ce6fdf255870a670e710c3714f7634fa

function SubAdminShell() {
  const navigate = useNavigate()
  const { logout } = useAuth()
  const [showLogout, setShowLogout] = useState(false)

<<<<<<< HEAD
  const shellRef = useRef(null)
  const noCardRef = useRef(null)
  const finishLogoutRef = useRef(null)

  // Soft parallax for the background blobs (mouse only, never for touch/reduced motion).
  usePointerDepth(shellRef, noCardRef)

  // Lets the Sub Admin's popups, menus and alerts (which render outside the
  // shell, on <body>) be styled without touching any other portal.
  useEffect(() => {
    document.body.classList.add('sb-theme')
    return () => document.body.classList.remove('sb-theme')
  }, [])

  useEffect(() => {
    finishLogoutRef.current = () => {
      logout()
      navigate('/')
    }
  })

  useEffect(() => {
    if (!showLogout) return undefined
    const timer = setTimeout(() => finishLogoutRef.current(), LOGOUT_LOADER_MS)
    return () => clearTimeout(timer)
  }, [showLogout])

  return (
    <div className="subadmin-shell" ref={shellRef}>
      <SubAdminSidebar onLogoutClick={() => setShowLogout(true)} />

      <main className="subadmin-shell-main">
        <div className="sb-ambient" aria-hidden="true">
          <div className="sb-blob-wrap" data-depth="26"><span className="sb-blob sb-blob-gold" /></div>
          <div className="sb-blob-wrap" data-depth="-20"><span className="sb-blob sb-blob-navy" /></div>
          <div className="sb-blob-wrap" data-depth="14"><span className="sb-blob sb-blob-sky" /></div>
          <span className="sb-grid" />
        </div>

        <SubAdminRouteLoader />
        <Outlet />
      </main>

      <SubAdminTooltips />

      <LoginLoader show={showLogout} label="Logging you out…" progressMs={LOGOUT_LOADER_MS} />
=======
  return (
    <div className="subadmin-shell">
      <SubAdminSidebar onLogoutClick={() => setShowLogout(true)} />

      <main className="subadmin-shell-main">
        <Outlet />
      </main>

      <WaitingPopup
        show={showLogout}
        label="Logging out..."
        durationMs={3000}
        onComplete={() => {
          logout()
          navigate('/')
        }}
      />
>>>>>>> ab8999e3ce6fdf255870a670e710c3714f7634fa
    </div>
  )
}

export default SubAdminShell
